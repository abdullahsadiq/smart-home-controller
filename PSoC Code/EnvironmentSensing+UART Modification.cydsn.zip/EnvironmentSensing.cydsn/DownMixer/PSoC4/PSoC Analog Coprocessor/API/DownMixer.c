/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "`$INSTANCE_NAME`.h"
#include "`$INSTANCE_NAME`_UABH_A.h"

void `$INSTANCE_NAME`_Start(void)
{
    `$INSTANCE_NAME`_UABH_A_Start();
}

/* [] END OF FILE */
