/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "DownMixer.h"
#include "DownMixer_UABH_A.h"

void DownMixer_Start(void)
{
    DownMixer_UABH_A_Start();
}

/* [] END OF FILE */
